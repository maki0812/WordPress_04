<div class="pick wrapper">
  <article class="pick-item">
    <img src="img/pickup1.jpg" alt="" />
    <h3 class="pick-ttl">タイトル</h3>
    <p class="pick-text">テキストテキストテキストテキストテキストテキストテキスト</p>
    <p class="pick-link"><a href="#">READ MORE</a></p>
  </article>
  <article class="pick-item">
    <img src="img/pickup2.jpg" alt="" />
    <h3 class="pick-ttl">タイトル</h3>
    <p class="pick-text">テキストテキストテキストテキストテキストテキストテキスト</p>
    <p class="pick-link"><a href="#">READ MORE</a></p>
  </article>
  <article class="pick-item">
    <img src="img/pickup3.jpg" alt="" />
    <h3 class="pick-ttl">タイトル</h3>
    <p class="pick-text">テキストテキストテキストテキストテキストテキストテキスト</p>
    <p class="pick-link"><a href="#">READ MORE</a></p>
  </article>
</div>



<main class="main wrapper">
  <div class="main-content">
    <article class="main__item">
      <div class="main__item-warap"><a href="#">
          <h2 class="main__item-ttl">タイトル</h2>
          <p class="main__item-ttl-text">テキストテキストテキストテキストテキストテキストテキスト</p>
          <p class="main__item-nav">
            <span class="main__item-date">2020/01/01</span>
            <span class="main__item-category">カテゴリ1</span>
          </p>
          <img src="img/main1.jpg" alt="" />
        </a></div>
      <p class="main__item-text">本文テキストテキストテキストテキストテキストテキストテキストテキスト テキストテキストテキストテキストテキストテキストテキストテキストテキスト
        テキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
      <p class="main__item-link"><a href="#">READ MORE</a></p>
    </article>
    <article class="main__item">
      <div class="main__item-warap"><a href="#">
          <h2 class="main__item-ttl">タイトル</h2>
          <p class="main__item-ttl-text">テキストテキストテキストテキストテキストテキストテキスト</p>
          <span class="main__item-date">2020/01/01</span>
          <span class="main__item-category">カテゴリ１</span>
          <img src="img/main2.jpg" alt="" />
        </a></div>
      <p class="main__item-text">本文テキストテキストテキストテキストテキストテキストテキストテキスト テキストテキストテキストテキストテキストテキストテキストテキストテキスト
        テキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
      <p class="main__item-link"><a href="#">READ MORE</a></p>
    </article>
    <article class="main__item">
      <div class="main__item-warap"><a href="#">
          <h2 class="main__item-ttl">タイトル</h2>
          <p class="main__item-ttl-text">テキストテキストテキストテキストテキストテキストテキスト</p>
          <span class="main__item-date">2020/01/01</span>
          <span class="main__item-category">カテゴリ１</span>
          <img src="img/main3.jpg" alt="" />
        </a></div>
      <p class="main__item-text">本文テキストテキストテキストテキストテキストテキストテキストテキスト テキストテキストテキストテキストテキストテキストテキストテキストテキスト
        テキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
      <p class="main__item-link"><a href="#">READ MORE</a></p>
    </article>
  </div>

</main>