<footer class="footer ">
  <div class="footer-content wrapper">
    <div class="footer-content-item">
      <div class="about">
        <h3 class="about__title">About</h3>
        <p class="about__text">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト
          テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
        <ul class="about__access">
          <li class="about__access-item"><a href="#">プロフィール詳細</a></li>
          <li class="about__access-item"><a href="#">お仕事の依頼</a></li>
          <li class="about__access-item"><a href="#">お問い合わせ</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-content-item">
      <div class="menu">
        <h3 class="menu__title">Menu</h3>
        <ul class="menu__list">
          <li class="menu__list-item"><a href="#">NEW</a></li>
          <li class="menu__list-item"><a href="#">CATEGPRY</a></li>
          <li class="menu__list-item"><a href="#">COLUMN</a></li>
          <li class="menu__list-item"><a href="#">SERIES</a></li>
          <li class="menu__list-item"><a href="#">Q&A</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-content-item">
      <div class="twitter">
        <h3 class="twitter__title">Twitter</h3>
      </div>
    </div>
  </div>
  <div class="footer-copyright">&copy;Travel & Blog</div>
</footer>
<script src="js/main.js"></script>
</body>

</html>