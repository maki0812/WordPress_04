  <aside class="sidebar">
    <div class="profile">
      <img src="img/author.jpg">
      <h3 class="profile-name">Name Name</h3>
      <p class="profile-text">プロフィールテキストテキストテキストテキストテキストテキストテキスト テキストテキストテキストテキストテキストテキストテキストテキストテキスト
        テキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
    </div>
    <div class="ranking">
      <h3 class="ranking__title">Ranking</h3>
      <div class="ranking__item"><a href="#">
          <img class="ranking__item-img" src="img/ranking1.jpg" alt="">
          <h4 class="ranking__item-title">タイトル</h4>
          <p class="ranking__item-text">テキストテキストテキストテキストテキストテキスト</p>
        </a>
      </div>
      <div class="ranking__item"><a href="#">
          <img class="ranking__item-img" src="img/ranking2.jpg" alt="">
          <h4 class="ranking__item-title">タイトル</h4>
          <p class="ranking__item-text">テキストテキストテキストテキストテキストテキスト</p>
        </a>
      </div>
      <div class="ranking__item"><a href="#">
          <img class="ranking__item-img" src="img/ranking3.jpg" alt="">
          <h4 class="ranking__item-title">タイトル</h4>
          <p class="ranking__item-text">テキストテキストテキストテキストテキストテキスト</p>
        </a>
      </div>
    </div>
    <div class="archive">
      <h3 class="archive__title">Archive</h3>
      <ul class="archive__item-list">
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
        <li class="archive__item"><a href="#">XXXX年XX月(XX)</a></li>
      </ul>
  </aside>